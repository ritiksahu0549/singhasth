import React from "react";
import { Container, Card, Row, Col } from "react-bootstrap";

const dates = [
  { event: "Peshwai", date: "March 25, 2028" },
  { event: "First Shahi Snan", date: "April 10, 2028" },
  { event: "Second Shahi Snan", date: "April 22, 2028" },
  { event: "Third Shahi Snan", date: "May 5, 2028" },
];

function DatesSection() {
  return (
    <Container className="py-5">
      <h2 className="text-center mb-4">Important Dates</h2>
      <Row>
        {dates.map((item, index) => (
          <Col md={6} lg={3} className="mb-4" key={index}>
            <Card>
              <Card.Body>
                <Card.Title>{item.event}</Card.Title>
                <Card.Text>{item.date}</Card.Text>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>
    </Container>
  );
}

export default DatesSection;
