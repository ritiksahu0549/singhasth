import React from "react";
import "./HeroSection.css";

function HeroSection() {
  return (
    <div className="hero-section d-flex align-items-center justify-content-center text-white text-center">
      <div className="bg-dark bg-opacity-50 p-4 rounded">
        <h1 className="display-4">Welcome to Simhastha 2028</h1>
        <p className="lead">Ujjain • The Spiritual Gathering</p>
      </div>
    </div>
  );
}

export default HeroSection;
