import React from "react";
import Navbar from "./components/Navbar";
import HeroSection from "./components/HeroSection";
import DatesSection from "./components/DatesSection";
import Footer from "./components/Footer";
import "bootstrap/dist/css/bootstrap.min.css";

function App() {
  return (
    <div className="d-flex flex-column min-vh-100">
      <Navbar />
      <main className="flex-grow-1">
        <HeroSection />
        <DatesSection />
      </main>
      <Footer />
    </div>
  );
}

export default App;
